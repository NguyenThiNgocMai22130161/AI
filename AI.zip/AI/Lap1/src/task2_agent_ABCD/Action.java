package task2_agent_ABCD; 

public abstract class Action {
	public abstract boolean isNoOp();
}