package chapter2.agent_AB; 

public abstract class Action {
	public abstract boolean isNoOp();
}