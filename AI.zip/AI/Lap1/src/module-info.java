/**
 * 
 */
/**
 * @author nguye
 *
 */
module Lap1 {
	requires java.desktop;
}