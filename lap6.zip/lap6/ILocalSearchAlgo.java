package A.student;

public interface ILocalSearchAlgo {
	public Node execute(Node initialState);
}
